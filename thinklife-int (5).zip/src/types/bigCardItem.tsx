export type bigCardItem = {
    icon: string;
    name: string;
    content: string;
    href: string;
};